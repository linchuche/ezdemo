package com.comslin.ezhome.oriUi.http.bean.room;

public class DeleteDevice {
    private int[] deviceIds;

    public int[] getDeviceIds() {
        return this.deviceIds;
    }

    public void setDeviceIds(int[] deviceIds) {
        this.deviceIds = deviceIds;
    }
}
