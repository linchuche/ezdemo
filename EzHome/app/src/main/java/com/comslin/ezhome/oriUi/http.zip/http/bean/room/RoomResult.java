package com.comslin.ezhome.oriUi.http.bean.room;

/**
 * Created by linChao on 2017-05-07.
 */

public class RoomResult {
}
