package com.comslin.ezhome.oriUi.http.bean.devices;

public class GatewayId {
    private int gatewayId;

    public int getGatewayId() {
        return this.gatewayId;
    }

    public void setGatewayId(int gatewayId) {
        this.gatewayId = gatewayId;
    }
}
