package com.comslin.ezhome.oriUi.http.bean.devices;

public class DeviceAdapterId {
    private int deviceAdapterId;

    public int getDeviceAdapterId() {
        return this.deviceAdapterId;
    }

    public void setDeviceAdapterId(int deviceAdapterId) {
        this.deviceAdapterId = deviceAdapterId;
    }
}
