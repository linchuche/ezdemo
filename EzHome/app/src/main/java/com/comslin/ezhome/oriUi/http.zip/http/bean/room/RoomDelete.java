package com.comslin.ezhome.oriUi.http.bean.room;

public class RoomDelete {
    private int[] roomIds;

    public int[] getRoomIds() {
        return this.roomIds;
    }

    public void setRoomIds(int[] roomIds) {
        this.roomIds = roomIds;
    }
}
