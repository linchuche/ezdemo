package com.comslin.ezhome.oriUi.http.bean.devices;

public class DeviceTypeId {
    private int deviceTypeId;

    public int getDeviceTypeId() {
        return this.deviceTypeId;
    }

    public void setDeviceTypeId(int deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }
}
