package com.comslin.ezhome.oriUi.http.bean.gateway;

/**
 * Created by linChao on 2017-04-25.
 */

public class GatewayId {

    private String gatewayId;

    public String getGatewayId() {
        return gatewayId;
    }

    public void setGatewayId(String gatewayId) {
        this.gatewayId = gatewayId;
    }
}
