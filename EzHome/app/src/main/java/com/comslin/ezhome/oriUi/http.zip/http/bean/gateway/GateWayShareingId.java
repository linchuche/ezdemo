package com.comslin.ezhome.oriUi.http.bean.gateway;

public class GateWayShareingId {
    private int gatewaySharingId;
    private boolean accept;

    public int getGatewaySharingId() {
        return this.gatewaySharingId;
    }

    public void setGatewaySharingId(int gatewaySharingId) {
        this.gatewaySharingId = gatewaySharingId;
    }

    public boolean getAccept() {
        return this.accept;
    }

    public void setAccept(boolean accept) {
        this.accept = accept;
    }
}
