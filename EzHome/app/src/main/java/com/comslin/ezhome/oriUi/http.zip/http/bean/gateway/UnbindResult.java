package com.comslin.ezhome.oriUi.http.bean.gateway;

public class UnbindResult {
}
